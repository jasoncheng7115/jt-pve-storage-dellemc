# Dell EMC storage plugins for Proxmox VE - PowerVault ME naming
# Copyright (c) 2026 Jason Cheng (Jason Tools)
# Licensed under the MIT License

package PVE::Storage::Custom::DellEMC::PowerVault::Naming;

use strict;
use warnings;

use base qw(PVE::Storage::Custom::DellEMC::Common::Naming);

# PowerVault ME names are severely constrained, and the constraints are
# documented rather than guessed:
#
#   "The value can have a maximum of 32 bytes. [...] can include spaces and
#    printable UTF-8 characters except: " , . < \"
#       -- ME5 Series CLI Reference Guide, `create volume`
#
#   Snapshot names have the same 32-byte limit, must be unique system-wide,
#   and exclude " , < \  (a dot is accepted there, but not in a volume name).
#       -- ME5 Series CLI Reference Guide, `create snapshots`
#
# Two consequences drive everything below.
#
# 1. A dot cannot be the volume/snapshot separator the way it is on
#    PowerStore, because a volume name may not contain one. This family uses
#    '-s-' for a snapshot and '-base' for the template marker instead.
#
# 2. 32 bytes is not much. 'pve-' plus a storeid plus a vmid plus a disk id
#    already spends most of it, so the disk component is abbreviated to 'd0'
#    rather than 'disk0', and the storeid gets a hard, small budget.
#
# The names this produces:
#
#     volume            pve-{prefix}-{vmid}-d{n}
#     cloud-init        pve-{prefix}-{vmid}-ci
#     EFI disk          pve-{prefix}-{vmid}-e{n}
#     TPM state         pve-{prefix}-{vmid}-t{n}
#     RAM state         pve-{prefix}-{vmid}-st-{snapname}
#     VM config backup  pve-{prefix}-{vmid}-vc-{snapname}
#     snapshot          {volume}-s-{snapname}
#     template marker   {volume}-base
#
# A snapshot name is decodable back to its volume by dropping the '-s-' tail,
# so the parent is never ambiguous even though the array also reports it.

use constant {
    MAX_NAME  => 32,
    SNAP_SEP  => '-s-',
    BASE_SUFFIX_ME => '-base',
};

sub max_volume_name_length   { MAX_NAME }
sub max_snapshot_name_length { MAX_NAME }

# Host names are limited too, but far less tightly than volumes.
sub max_host_name_length     { 32 }

# 'pve-' + storeid + '-' + vmid(<=8) + '-d' + n(<=3) has to fit in 32, and a
# snapshot then needs '-s-' plus something meaningful after it. Ten characters
# of storeid leaves room for a six-character snapshot name.
sub max_storeid_length { 10 }

# A dot is not permitted in a PowerVault volume name at all.
sub name_charclass_re { qr/[^A-Za-z0-9_-]/ }

my $PFX = qr/[A-Za-z0-9_]+/;

# Same rule as the parent class: a digit run too long to be a PVE vmid is not
# a name this plugin wrote.
sub _valid_vmid {
    return PVE::Storage::Custom::DellEMC::Common::Naming::_valid_vmid($_[0]);
}

# Built per call, not compiled once: the leading component is configurable and
# a constant here would decode nothing for a storage that sets it. Same reason
# as in Common::Naming, and grepped for here because a guard added to one
# family is worth nothing until it is applied to the others.
sub _re {
    my ($class, $body) = @_;
    my $p = quotemeta($class->name_prefix);
    return qr/^$p-($PFX)-$body/;
}

sub _RE_DISK      { $_[0]->_re(qr/(\d+)-d(\d+)\z/) }
sub _RE_CLOUDINIT { $_[0]->_re(qr/(\d+)-ci\z/) }
sub _RE_EFIDISK   { $_[0]->_re(qr/(\d+)-e(\d+)\z/) }
sub _RE_TPMSTATE  { $_[0]->_re(qr/(\d+)-t(\d+)\z/) }
sub _RE_STATE     { $_[0]->_re(qr/(\d+)-st-(.+)\z/) }
sub _RE_VMCONF    { $_[0]->_re(qr/(\d+)-vc-(.+)\z/) }

# A snapshot name is <volume>-s-<snapname>, and BOTH halves can contain the
# separator, so neither a greedy nor a lazy match is right.
#
#   Greedy '^(.+)-s-(.+)$' takes the LAST '-s-'. A snapshot PVE happily
#   accepts, 'before-s-after', then decodes as a snapshot of a volume that
#   does not exist — invisible to volume_snapshot_list, missed by the purge
#   that has to run before a volume can be deleted.
#
#   Lazy '^(.+?)-s-(.+)$' takes the FIRST, which breaks a storage whose id
#   sanitises to 's': its volumes are named 'pve-s-100-d0' and the volume name
#   itself contains '-s-'.
#
# So the volume half is matched by its actual shape, and everything after the
# separator that follows it is the snapshot name, whatever it contains.
my $RE_VOLUME_PART = qr/pve-$PFX-\d+-(?:d\d+|ci|e\d+|t\d+|st-.+|vc-.+)/;

my $RE_SNAPSHOT  = qr/^($RE_VOLUME_PART)-s-(.+)\z/;
my $RE_BASESNAP  = qr/^($RE_VOLUME_PART)-base\z/;

# ---------------------------------------------------------------------------
# Encoding
# ---------------------------------------------------------------------------

sub encode_volume_name {
    my ($class, $storeid, $vmid, $diskid) = @_;

    die "storeid is required\n" unless defined $storeid;
    die "vmid is required\n"    unless defined $vmid;
    die "diskid is required\n"  unless defined $diskid;

    return $class->_fit_name($class->volume_prefix($storeid) . "${vmid}-d${diskid}");
}

sub encode_cloudinit_name {
    my ($class, $storeid, $vmid) = @_;
    die "vmid is required\n" unless defined $vmid;
    return $class->_fit_name($class->volume_prefix($storeid) . "${vmid}-ci");
}

sub encode_efidisk_name {
    my ($class, $storeid, $vmid, $diskid) = @_;
    die "vmid is required\n"   unless defined $vmid;
    die "diskid is required\n" unless defined $diskid;
    return $class->_fit_name($class->volume_prefix($storeid) . "${vmid}-e${diskid}");
}

sub encode_tpmstate_name {
    my ($class, $storeid, $vmid, $diskid) = @_;
    die "vmid is required\n"   unless defined $vmid;
    die "diskid is required\n" unless defined $diskid;
    return $class->_fit_name($class->volume_prefix($storeid) . "${vmid}-t${diskid}");
}

sub encode_state_name {
    my ($class, $storeid, $vmid, $snapname) = @_;

    die "vmid is required\n"     unless defined $vmid;
    die "snapname is required\n" unless defined $snapname;

    my $prefix = $class->volume_prefix($storeid) . "${vmid}-st-";
    return $prefix . $class->_fit_suffix($prefix, $snapname);
}

sub encode_config_volume_name {
    my ($class, $storeid, $vmid, $snapname) = @_;

    die "vmid is required\n"     unless defined $vmid;
    die "snapname is required\n" unless defined $snapname;

    my $prefix = $class->volume_prefix($storeid) . "${vmid}-vc-";
    return $prefix . $class->_fit_suffix($prefix, $snapname);
}

# A generated name that does not fit is a bug, not something to paper over: a
# silently truncated volume name can collide with another VM's.
sub _fit_name {
    my ($class, $name) = @_;

    # The limit comes from the class, never from the constant: PowerFlex
    # subclasses this module with a limit of 31, and reading MAX_NAME here
    # would silently apply PowerVault's 32 to it.
    my $max = $class->max_volume_name_length;

    return $name if length($name) <= $max;

    die "Generated name '$name' is " . length($name) . " bytes, but this array"
      . " accepts at most $max. Use a shorter storage id: this family has far"
      . " less room for names than PowerStore does.\n";
}

sub encode_snapshot_name {
    my ($class, $volume, $snapname) = @_;

    die "volume is required\n"   unless defined $volume;
    die "snapname is required\n" unless defined $snapname;

    my $max    = $class->max_snapshot_name_length;
    my $prefix = $volume . SNAP_SEP;
    my $budget = $max - length($prefix);

    die "Volume name '$volume' leaves no room for a snapshot name on this"
      . " array, which allows $max bytes in total. Use a shorter storage"
      . " id.\n" if $budget < 1;

    my $snap = $class->sanitize($snapname, $budget);
    $snap = substr($snap, 0, $budget);
    $snap =~ s/[-_]+$//;
    $snap = 's' unless length $snap;

    $class->_assert_snapname_survives($snapname, $snap, $budget);

    return $prefix . $snap;
}

# Two characters, not nine: on a 32-byte name the infix is most of the budget.
sub temp_clone_infix { '-t' }

sub encode_base_snapshot_name {
    my ($class, $volume) = @_;

    die "volume is required\n" unless defined $volume;

    my $name = $volume . BASE_SUFFIX_ME;

    die "Volume name '$volume' leaves no room for the template marker"
      . " snapshot, which would be " . length($name) . " bytes against a limit"
      . " of " . $class->max_snapshot_name_length . ". Use a shorter storage"
      . " id.\n" if length($name) > $class->max_snapshot_name_length;

    return $name;
}

# ---------------------------------------------------------------------------
# Decoding
# ---------------------------------------------------------------------------

sub decode_volume_name {
    my ($class, $name) = @_;

    return undef unless defined $name;

    # A snapshot is a name with a '-s-' or '-base' tail; decode those with
    # decode_snapshot_name instead.
    return undef if $name =~ $RE_SNAPSHOT;
    return undef if $name =~ $RE_BASESNAP;

    if ($name =~ $class->_RE_DISK) {
        my $vmid = _valid_vmid($2) or return undef;
        return { storage => $1, vmid => $vmid, diskid => int($3), type => 'disk' };
    }
    if ($name =~ $class->_RE_CLOUDINIT) {
        my $vmid = _valid_vmid($2) or return undef;
        return { storage => $1, vmid => $vmid, type => 'cloudinit' };
    }
    if ($name =~ $class->_RE_EFIDISK) {
        my $vmid = _valid_vmid($2) or return undef;
        return { storage => $1, vmid => $vmid, diskid => int($3), type => 'efidisk' };
    }
    if ($name =~ $class->_RE_TPMSTATE) {
        my $vmid = _valid_vmid($2) or return undef;
        return { storage => $1, vmid => $vmid, diskid => int($3), type => 'tpmstate' };
    }
    if ($name =~ $class->_RE_STATE) {
        my $vmid = _valid_vmid($2) or return undef;
        return { storage => $1, vmid => $vmid, snapname => $3, type => 'state' };
    }
    if ($name =~ $class->_RE_VMCONF) {
        my $vmid = _valid_vmid($2) or return undef;
        return { storage => $1, vmid => $vmid, snapname => $3, type => 'vmconf' };
    }

    return undef;
}

sub decode_snapshot_name {
    my ($class, $name) = @_;

    return undef unless defined $name;

    if ($name =~ $RE_SNAPSHOT) {
        return { volume => $1, snapname => $2, is_base => 0 };
    }
    if ($name =~ $RE_BASESNAP) {
        return { volume => $1, snapname => undef, is_base => 1 };
    }

    return undef;
}

sub is_config_volume {
    my ($class, $name) = @_;
    return 0 unless defined $name;
    return $name =~ $class->_RE_VMCONF ? 1 : 0;
}

sub is_state_volume {
    my ($class, $name) = @_;
    return 0 unless defined $name;
    return $name =~ $class->_RE_STATE ? 1 : 0;
}

sub array_to_pve_volname {
    my ($class, $name) = @_;

    my $d = $class->decode_volume_name($name);
    return undef unless $d;

    my $vmid = $d->{vmid};
    my $type = $d->{type};

    return "vm-${vmid}-disk-$d->{diskid}"    if $type eq 'disk';
    return "vm-${vmid}-cloudinit"            if $type eq 'cloudinit';
    return "vm-${vmid}-efidisk$d->{diskid}"  if $type eq 'efidisk';
    return "vm-${vmid}-tpmstate$d->{diskid}" if $type eq 'tpmstate';
    return "vm-${vmid}-state-$d->{snapname}" if $type eq 'state';

    return undef;
}

sub is_valid_volume_name {
    my ($class, $name) = @_;

    return 0 unless defined $name && length($name);
    return 0 if length($name) > $class->max_volume_name_length;
    # The array forbids " , . < \ ; this plugin never generates anything but
    # alphanumerics, '-' and '_' anyway.
    return 0 unless $name =~ /^[A-Za-z0-9][A-Za-z0-9_-]*\z/;

    return 1;
}

sub is_valid_snapshot_name {
    my ($class, $name) = @_;

    return 0 unless defined $name && length($name);
    return 0 if length($name) > $class->max_snapshot_name_length;
    return 0 unless $name =~ /^[A-Za-z0-9][A-Za-z0-9_-]*\z/;

    return 1;
}

1;

__END__

=head1 NAME

PVE::Storage::Custom::DellEMC::PowerVault::Naming - name limits for PowerVault
ME series arrays

=head1 DESCRIPTION

PowerVault ME accepts at most 32 bytes for a volume or snapshot name, and a
volume name may not contain a dot. Both are documented in the ME5 Series CLI
Reference Guide under C<create volume> and C<create snapshots>.

That is far tighter than PowerStore, so this family shortens the object names
(C<d0> rather than C<disk0>) and separates a snapshot from its volume with
C<-s-> rather than a dot.

A generated name that would exceed 32 bytes raises an error naming the storage
id as the thing to shorten. Silently truncating would let two VMs' volumes
collide on one name.

=head1 AUTHOR

Jason Cheng (Jason Tools) <jason@jason.tools>

=head1 LICENSE

MIT License

=cut
