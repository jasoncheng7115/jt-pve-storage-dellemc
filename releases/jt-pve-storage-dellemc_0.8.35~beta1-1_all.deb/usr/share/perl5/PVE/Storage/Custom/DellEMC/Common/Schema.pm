# Dell EMC storage plugins for Proxmox VE - shared storage.cfg schema
# Copyright (c) 2026 Jason Cheng (Jason Tools)
# Licensed under the MIT License

package PVE::Storage::Custom::DellEMC::Common::Schema;

use strict;
use warnings;

# The dell-* options every Dell EMC family shares, and the rule that decides
# which plugin declares them.
#
# PVE merges every registered plugin's properties() into ONE schema and dies
# with "duplicate property" if two plugins declare the same name — see
# PVE::SectionConfig::init. That failure is not scoped to the offending
# plugin: it happens while PVE builds the storage schema, so every storage on
# the node stops working.
#
# So exactly one registered class may declare the shared options. Whichever
# family PVE asks first takes the job; the rest declare only their own. This
# lives here rather than in BlockBase because PowerFlex needs the same shared
# options while having nothing else in common with a block plugin.

my $OWNER;

sub common_properties {
    return {
        'dell-portal' => {
            title => "Management Address",
            description => "Management address(es) of the array. Several may"
                . " be given comma-separated - on an array whose controllers"
                . " each have their own management IP and no floating address"
                . " (PowerVault ME, Unity), list both controllers so"
                . " management survives a controller failover. The data path"
                . " needs nothing: dm-multipath handles that on its own.",
            type => 'string',
        },
        'dell-username' => {
            title => "Username",
            description => "Username for the array's management API.",
            type => 'string',
        },
        'dell-password' => {
            title => "Password",
            description => "Password for the array's management API.",
            type => 'string',
        },
        'dell-ssl-verify' => {
            title => "Verify SSL Certificate",
            description => "Verify the array's SSL certificate.",
            type => 'boolean',
            default => 0,
        },
        'dell-protocol' => {
            title => "Protocol",
            description => "Data path: 'iscsi' or 'fc' on the SAN families,"
                . " 'sdc' or 'nvme' on PowerFlex.",
            type => 'string',
            enum => ['iscsi', 'fc', 'sdc', 'nvme'],
            default => 'iscsi',
        },
        'dell-name-prefix' => {
            title => "Name Prefix",
            description => "Leading component of every object this storage"
                . " creates on the array, so 'pve-<storage>-<vmid>-disk0'"
                . " becomes '<prefix>-<storage>-<vmid>-disk0'. Defaults to"
                . " 'pve' and normally needs no thought. It exists for two"
                . " Proxmox CLUSTERS attached to one array: the namespace is"
                . " otherwise the storage id, so two clusters that both call"
                . " a storage 'ps1' share every volume name. Set at 'pvesm"
                . " add' time only - changing it later would make this plugin"
                . " stop recognising the volumes it has already created, so an"
                . " update that changes it is refused.",
            type => 'string',
            pattern => '[a-z][a-z0-9]{1,15}',
            default => 'pve',
            optional => 1,
        },
        'dell-host-mode' => {
            title => "Host Mode",
            description => "How host objects are created on the array."
                . " 'per-node' registers one host per PVE node, which is what"
                . " lets the array report per-node connectivity. 'shared'"
                . " registers a SINGLE HOST OBJECT for the whole cluster, with"
                . " every node's initiators in it; it is not an array host"
                . " group. 'host-group' keeps the per-node host objects and"
                . " ALSO puts them in an array host group named after the"
                . " cluster, so one mapping reaches every node (PowerStore"
                . " only). A host that is already a member of some other group"
                . " is left there and mapped through that group: a host"
                . " belongs to at most one host group and is mapped through"
                . " it, so moving it would take away whatever that group maps."
                . " Whatever the mode, a host group that already exists is"
                . " always mapped through, because a host in a group cannot be"
                . " mapped any other way.",
            type => 'string',
            enum => ['per-node', 'shared', 'host-group'],
            default => 'per-node',
        },
        'dell-cluster-name' => {
            title => "Cluster Name",
            description => "Cluster name used when naming host objects on the"
                . " array. Distinguishes several PVE clusters sharing one array.",
            type => 'string',
            default => 'pve',
            optional => 1,
        },
        'dell-device-timeout' => {
            title => "Device Timeout (s)",
            description => "Seconds to wait for a volume's device to appear"
                . " after it has been mapped.",
            type => 'integer',
            minimum => 10,
            maximum => 300,
            default => 60,
        },
        'dell-portal-probe-timeout' => {
            title => "Portal Probe Timeout (s)",
            description => "Seconds for the TCP pre-check that skips iSCSI"
                . " portals this node cannot reach, before iscsiadm discovery"
                . " and login are attempted. Arrays routinely publish more"
                . " portal addresses than a given node is cabled for, and each"
                . " unreachable one otherwise costs 30s discovery plus 60s"
                . " login. Set to 0 to disable the pre-check.",
            type => 'integer',
            minimum => 0,
            maximum => 30,
            default => 2,
        },
        'dell-status-timeout' => {
            title => "Status Timeout (s)",
            description => "API timeout in seconds on the pvestatd health path"
                . " (activate_storage and the foreground of status). That path"
                . " is polled roughly every 10 seconds and PVE processes"
                . " storages sequentially, so a slow array would otherwise back"
                . " up the whole cycle and starve sibling storages on the node"
                . " into 'inactive'. The health client makes a single attempt:"
                . " the next poll is the retry.",
            type => 'integer',
            minimum => 2,
            maximum => 60,
            default => 5,
        },
        'dell-activate-deadline' => {
            title => "Activation Deadline (s)",
            description => "Cumulative wall-clock budget in seconds for the"
                . " iSCSI portal discovery and login loop in activate_storage."
                . " Once the budget is spent AND at least one portal is logged"
                . " in, the rest are deferred to a later activation. Never"
                . " enforced while zero paths are up. Set to 0 to disable.",
            type => 'integer',
            minimum => 0,
            maximum => 300,
            default => 30,
        },
        'dell-rollback-any-snapshot' => {
            title => "Rollback to Any Snapshot",
            description => "Allow rolling back to a snapshot that is not the"
                . " most recent one. Off by default: Dell does not document"
                . " what a restore does to the snapshots taken after the one"
                . " being restored, and on an array that discards them PVE"
                . " would go on listing restore points that no longer exist."
                . " Turn this on only if you have verified the behaviour on"
                . " your own array and model.",
            type => 'boolean',
            default => 0,
            optional => 1,
        },
        'dell-config-backup' => {
            title => "Config Backup",
            description => "Write the VM configuration to a small volume"
                . " beside each snapshot, so it can be recovered when"
                . " /etc/pve is gone. Each snapshot of a VM costs one extra"
                . " volume on the array, so turn this off on an array whose"
                . " volume count is the binding limit. Families whose limits"
                . " are too low do not offer it at all.",
            type => 'boolean',
            default => 1,
            optional => 1,
        },
        'dell-config-backup-timeout' => {
            title => "Config Backup Timeout (s)",
            description => "Seconds to wait for the auxiliary 1 MB config"
                . " backup volume's device. That volume is only read by"
                . " pve-dell-config-get for disaster recovery, so it has a"
                . " shorter timeout of its own. The wait happens in a"
                . " detached background process, after the snapshot has"
                . " returned and the guest's filesystems have been thawed, so"
                . " raising this no longer lengthens the freeze - it only"
                . " gives a slow fabric more time to present the device.",
            type => 'integer',
            minimum => 5,
            maximum => 60,
            default => 15,
        },
        'dell-rescan-interval' => {
            title => "Rescan Interval (s)",
            description => "Minimum seconds between the periodic SAN rescans"
                . " activate_storage performs. PVE calls activate_storage on"
                . " every pvestatd poll, so running a host-wide multipath"
                . " reconfigure and udev trigger unconditionally means doing it"
                . " six times a minute on every node, which keeps device-mapper"
                . " in flux while other operations are trying to discover"
                . " devices. A rescan always happens immediately when this node"
                . " logs in to a new portal. Set to 0 to rescan on every"
                . " activation.",
            type => 'integer',
            minimum => 0,
            maximum => 3600,
            default => 300,
            optional => 1,
        },
    };
}

sub common_options {
    return {
        'dell-portal'                => { fixed => 1 },
        'dell-username'              => {},
        # Optional in the OPTION list because it is a sensitive property: PVE
        # strips it out of the parameters before validating them against this
        # schema, so a required entry here fails every 'pvesm add' with
        # "missing value for required option". PBS declares its password the
        # same way, for the same reason. The password is not optional in
        # practice - _api dies without one - it is simply never in the config.
        'dell-password'              => { optional => 1 },
        'dell-ssl-verify'            => { optional => 1 },
        'dell-protocol'              => { optional => 1 },
        'dell-name-prefix'           => { optional => 1 },
        'dell-host-mode'             => { optional => 1 },
        'dell-cluster-name'          => { optional => 1 },
        'dell-device-timeout'        => { optional => 1 },
        'dell-portal-probe-timeout'  => { optional => 1 },
        'dell-status-timeout'        => { optional => 1 },
        'dell-activate-deadline'     => { optional => 1 },
        'dell-rollback-any-snapshot' => { optional => 1 },
        'dell-config-backup'         => { optional => 1 },
        'dell-config-backup-timeout' => { optional => 1 },
        'dell-rescan-interval'       => { optional => 1 },
        nodes   => { optional => 1 },
        disable => { optional => 1 },
        content => { optional => 1 },
        shared  => { optional => 1 },
    };
}

# The shared options PVE 9.3's generated add/edit dialog puts under
# "Advanced" rather than on the first page. Tuning knobs with defaults that
# fit, and the two names that must not change after 'pvesm add'. Nothing is
# HIDDEN: a hidden option cannot be set from the dialog at all, and every one
# of these is something an operator may need. Older PVE ignores the key.
sub advanced_properties {
    return {
        map { $_ => 1 } qw(
            dell-name-prefix dell-cluster-name
            dell-device-timeout dell-portal-probe-timeout dell-status-timeout
            dell-activate-deadline dell-rescan-interval
            dell-rollback-any-snapshot
            dell-config-backup dell-config-backup-timeout
        )
    };
}

# The plugindata() keys PVE 9.3 reads to build a third-party plugin's dialog:
# the advanced section and the type's display name. A family adds its own
# advanced options. Ignored by PVE before 9.3, which has no such dialog.
sub ui_plugindata {
    my ($class, $display_name, @family_advanced) = @_;
    return (
        'advanced-properties' => {
            %{ $class->advanced_properties() },
            map { $_ => 1 } @family_advanced,
        },
        meta => { 'display-name' => $display_name },
    );
}

# What a family plugin's properties() should return: its own, plus the shared
# ones if it is the family that got asked first.
sub properties {
    my ($class, $family_class, $family_properties) = @_;

    my $props = { %{ $family_properties // {} } };

    $OWNER = $family_class unless defined $OWNER;
    if ($OWNER eq $family_class) {
        my $common = $class->common_properties();
        $props->{$_} //= $common->{$_} for keys %$common;
    }

    return $props;
}

# Options are safe to repeat: PVE looks each one up in the merged property
# list and only complains when nothing declared it.
sub options {
    my ($class, $family_options) = @_;

    return {
        %{ $class->common_options() },
        %{ $family_options // {} },
    };
}

# Which class declared the shared options. Tests use this; nothing else
# should need it.
sub owner { return $OWNER }

# Test seam only.
sub _reset_owner { $OWNER = undef; return }

1;

__END__

=head1 NAME

PVE::Storage::Custom::DellEMC::Common::Schema - the shared storage.cfg
options and the rule for declaring them once

=head1 DESCRIPTION

PVE merges every plugin's C<properties()> into one schema and dies on a
duplicate name, which takes down every storage on the node rather than just
the offending plugin. The shared C<dell-*> options are therefore declared by
whichever family class PVE asks first.

=head1 AUTHOR

Jason Cheng (Jason Tools) <jason@jason.tools>

=head1 LICENSE

MIT License

=cut
