# Dell EMC storage plugins for Proxmox VE - PowerStore REST client
# Copyright (c) 2026 Jason Cheng (Jason Tools)
# Licensed under the MIT License

package PVE::Storage::Custom::DellEMC::PowerStore::API;

use strict;
use warnings;

use base qw(PVE::Storage::Custom::DellEMC::Common::REST);

use HTTP::Cookies;
use JSON qw(decode_json);
use MIME::Base64 qw(encode_base64);

# PowerStore Manager REST client.
#
# The endpoints and request bodies here are the ones Dell's own
# python-powerstore SDK sends — PyPowerStore/utils/constants.py for the paths,
# provisioning.py for the payloads — and the initiator and os_type values are
# the enums ansible-powerstore documents. What is still unchecked is the
# RESPONSE field set: what the array puts in a row, which differs between 3.x
# and 4.x. Compare it against a real appliance's own Swagger UI at
# https://<mgmt-ip>/swaggerui — see docs/TESTING.md.
#
# Filtering follows PostgREST conventions, which PowerStore adopted:
#   name=eq.<value>            exact match
#   name=ilike.<prefix>*       case-insensitive match, '*' the documented
#                              wildcard (see _prefix_filter)
#   type=eq.Snapshot           enum match
# Filters are applied server-side, always. Listing every volume and filtering
# locally turns each poll into a full inventory transfer, and this plugin
# polls every ten seconds per node.

use constant {
    BASE_PATH => '/api/rest',

    # PowerStore requires volume sizes to be a multiple of 8 KiB.
    SIZE_GRANULARITY => 8192,

    # And refuses one below 1 MiB outright, however well it is aligned.
    # PVE asks for less than that exactly once, and it is not a corner case:
    # an OVMF EFI disk is allocated at the size of OVMF_VARS_4M.fd, which is
    # 540672 bytes (528 KiB) -- and 540672 is ALREADY a multiple of 8 KiB, so
    # rounding leaves it untouched and the array answers "The minimum
    # supported volume size is 1048576". Every UEFI guest moved to this
    # storage failed on its EFI disk while its ordinary disks migrated.
    # Reported against 0.8.15 from a customer's PowerStore (issue #1); Dell's
    # own ansible-powerstore documents the same limit ("Minimum volume size
    # is 1MB").
    MIN_VOLUME_SIZE => 1024 * 1024,

    # The developers guide documents the pagination limit as 1 to 2000, 100
    # by default, and answers 206 Partial Content with a Content-Range header
    # when the collection is larger. 200 keeps a poll's response small while
    # still costing one round trip for any storage of a realistic size.
    PAGE_SIZE => 200,

    # Guard against an endless paging loop if the array keeps returning full
    # pages (a filter it ignored, a bug). 100k volumes is far past any
    # plausible PVE storage.
    MAX_PAGES => 500,

    # LUN ids the array accepts for a host mapping.
    MIN_LUN_ID => 1,
    MAX_LUN_ID => 255,

    JOB_POLL_INTERVAL => 2,
    JOB_POLL_TIMEOUT  => 300,
};

sub base_path { BASE_PATH }

# ---------------------------------------------------------------------------
# Authentication
#
# GET /login_session with HTTP Basic returns a DELL-EMC-TOKEN header and a
# session cookie. Both are required on writes; reads accept the cookie alone.
# ---------------------------------------------------------------------------

sub _init_ua {
    my ($self) = @_;

    my $ua = $self->SUPER::_init_ua();
    # The session cookie is half of the credential pair.
    $ua->cookie_jar(HTTP::Cookies->new) if $ua->can('cookie_jar');

    return $ua;
}

sub _login {
    my ($self) = @_;

    my $auth = encode_base64("$self->{username}:$self->{password}", '');

    my $resp = $self->_request('GET', '/login_session', undef,
        no_auth => 1,
        raw     => 1,
        headers => { Authorization => "Basic $auth" },
    );

    my $token = $resp->header('DELL-EMC-TOKEN');
    unless ($token) {
        die $self->_msg(
            "login succeeded but the array returned no DELL-EMC-TOKEN header."
          . " Verify that this endpoint is a PowerStore management address.")
          . "\n";
    }

    return $self->_mark_session({ token => $token });
}

sub _auth_headers {
    my ($self) = @_;

    # The cookie jar on the user agent carries the session cookie; the token
    # is what the array checks on writes.
    return ('DELL-EMC-TOKEN' => $self->{_session}{token});
}

# Dell documents the CSRF token as something to fetch with a GET before each
# write, which leaves it open whether the array reissues it as the session
# goes on. Rather than depend on the answer, take the newest one the array
# has offered: if it never rotates, this writes back the same string.
sub _note_response {
    my ($self, $resp) = @_;

    return unless $self->{_session};

    my $token = $resp->header('DELL-EMC-TOKEN');
    return unless defined $token && length $token;

    $self->{_session}{token} = $token;

    return;
}

# The session cookie is as much of the credential as the token is, so a
# cleared session must not leave the old one in the jar for the next login to
# present alongside fresh Basic credentials.
sub _clear_session {
    my ($self) = @_;

    if (my $ua = $self->{_ua}) {
        my $jar = $ua->can('cookie_jar') ? $ua->cookie_jar : undef;
        $jar->clear() if $jar && $jar->can('clear');
    }

    return $self->SUPER::_clear_session();
}

sub _logout {
    my ($self) = @_;

    return unless $self->_session_to_release;

    $self->_release_request('POST', '/logout', {});

    return;
}

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

# PowerStore returns { messages => [ { code, severity, message_l10n } ] },
# which the base class already renders. What it cannot know is which codes
# mean something the operator can act on.
sub error_hint {
    my ($self, $code) = @_;

    return 'authentication failed. Verify dell-username and dell-password,'
         . ' and that the account is not locked out in PowerStore Manager.'
        if $code == 401;

    return 'permission denied. The account needs at least the Storage'
         . ' Operator role for volume operations.'
        if $code == 403;

    return 'the object was not found. It may have been deleted in PowerStore'
         . ' Manager, or the appliance may have been failed over.'
        if $code == 404;

    return 'the request conflicts with the array state: the object may'
         . ' already exist, still be attached, or still have snapshots or'
         . ' thin clones depending on it.'
        if $code == 422;

    return $self->SUPER::error_hint($code);
}

# ---------------------------------------------------------------------------
# Collections
# ---------------------------------------------------------------------------

# GET a collection, following pages. $params are filter/select parameters.
#
# The page size the array uses is NOT necessarily the one we asked for: a
# server-side cap, or a large row, can make it answer with fewer. Stopping on
# a short page would then silently truncate the result — which does not fail
# anywhere visible, it just hides volumes from the disk list AND leaves the
# orphan reaper with an incomplete alive set, so live volumes past the cut are
# treated as deleted. The array says what it did in the Content-Range header
# that comes with 206 Partial Content ('items 0-99/1234'), so the total is
# what decides, and the short-page heuristic is only the fallback for a
# response that carries no such header.
sub _collection {
    my ($self, $endpoint, $params, %opts) = @_;

    my @rows;
    my $offset = 0;
    my $total;

    for my $page (1 .. MAX_PAGES) {
        my %query = (%{ $params // {} }, limit => PAGE_SIZE, offset => $offset);

        my $resp = $self->get($endpoint, \%query, %opts,
            raw => 1, allow_status => [416]);

        # 416 Range Not Satisfiable is what the array answers for an offset
        # past the end of the collection. Reaching one is not an error here:
        # it means the collection shrank while it was being paged, which is
        # what a volume deleted on another node during a listing looks like.
        # Dying on it would turn an ordinary concurrent delete into a storage
        # that reports itself broken.
        last if $resp->code == 416;

        # Bytes, not characters: see REST::_decode_success.
        my $body  = $self->_response_bytes($resp) // '';
        my $batch = length($body) ? eval { decode_json($body) } : [];
        if ($@) {
            die $self->_msg("GET $endpoint returned a body that is not JSON:"
                . " $@") . "\n";
        }
        $batch = [] unless ref($batch) eq 'ARRAY';

        push @rows, @$batch;

        # An empty page always ends it, whatever the headers say.
        last unless @$batch;

        # 'Content-Range: 0-99/1000' — the figure after the slash is how many
        # rows match in total. '*' means the array will not say. Some
        # implementations prefix the unit ('items 0-99/1000'), which is why
        # only the tail is matched.
        if (my $range = $resp->header('Content-Range')) {
            my ($reported) = $range =~ m{/\s*(\d+)\s*$};
            $total = $reported if defined $reported;
        }

        # Advance by what actually arrived, not by what was requested.
        $offset += scalar(@$batch);

        if (defined $total) {
            last if $offset >= $total;
        } else {
            last if scalar(@$batch) < PAGE_SIZE;
        }

        if ($page == MAX_PAGES) {
            $self->log_warn("stopped paging $endpoint after " . MAX_PAGES
                . " pages (" . scalar(@rows) . " rows"
                . (defined $total ? " of $total" : '') . "); the result is"
                . " incomplete and volumes past this point are not visible to"
                . " this plugin");
        }
    }

    return \@rows;
}

# A prefix match, done in the way Dell's own examples write it.
#
# The developers guide documents ilike as a case-insensitive match "with
# wildcard support" and every example it gives spells the wildcard '*'
# (?name=ilike.User*). PostgREST, which this filter syntax comes from, accepts
# '%' as well — but only the '*' form is documented, so that is the one to
# send.
#
# Getting this wrong is not a visible failure. A wildcard the array treats as
# an ordinary character matches nothing, the collection comes back empty, and
# every volume on the storage disappears from PVE while the array still holds
# them. So the wildcard is never trusted on its own: see _collection_prefixed.
sub _prefix_filter {
    my ($self, $prefix) = @_;

    return 'ilike.' . $prefix . '*';
}

# A collection filtered by name prefix, that cannot silently come back empty
# because the array read the wildcard differently than documented.
#
# The server-side filter is what keeps a poll from transferring the whole
# array's inventory every ten seconds, so it stays. But an empty result is
# also exactly what a misread wildcard produces, and that answer is
# indistinguishable from "this storage has no volumes yet". When the filtered
# query finds nothing, ask once more without the name filter and match the
# prefix here. On a storage that genuinely holds nothing this costs one listing
# of volumes that are not ours; if it ever finds rows the filter missed, the
# wildcard is wrong for this array and the log says so in as many words.
sub _collection_prefixed {
    my ($self, $endpoint, $prefix, $params, %opts) = @_;

    my $filtered = $self->_collection($endpoint,
        { %{ $params // {} }, name => $self->_prefix_filter($prefix) }, %opts);

    # Trust the prefix, not the filter: a match that is broader than a prefix
    # would otherwise pull in another storage's volumes.
    my @kept = grep { defined $_->{name} && index($_->{name}, $prefix) == 0 }
        @$filtered;

    return \@kept if @kept;

    my $all = $self->_collection($endpoint, $params, %opts);
    my @local = grep { defined $_->{name} && index($_->{name}, $prefix) == 0 }
        @$all;

    if (@local) {
        $self->_warn_wildcard($endpoint, $prefix, scalar @local);
    }

    return \@local;
}

sub _warn_wildcard {
    my ($self, $endpoint, $prefix, $found) = @_;

    return if $self->{_wildcard_warned};
    $self->{_wildcard_warned} = 1;

    $self->log_warn("the array's name filter matched nothing on $endpoint for"
        . " prefix '$prefix', but $found row(s) match it here. This appliance"
        . " reads the ilike wildcard differently than the developers guide"
        . " documents; the plugin is filtering locally instead, which is"
        . " correct but slower. Please report it.");

    return;
}

# The fields worth asking for on a volume. Selecting explicitly keeps the
# response small and stable; PowerStore returns a large object otherwise.
sub _volume_select {
    return 'id,name,size,wwn,type,state,appliance_id,creation_timestamp,'
         . 'protection_data,logical_used';
}

# ---------------------------------------------------------------------------
# Cluster and capacity
# ---------------------------------------------------------------------------

sub cluster_get {
    my ($self, %opts) = @_;

    my $rows = $self->get('/cluster', { select => 'id,name,state,system_time' }, %opts);

    return ref($rows) eq 'ARRAY' ? $rows->[0] : $rows;
}

sub appliance_list {
    my ($self, %opts) = @_;
    return $self->_collection('/appliance', { select => 'id,name,model' }, %opts);
}

# Space figures out of one metrics record.
#
# Returns (total, used), either of which may be 0 when the record does not
# carry it. The candidates are collected and the first that is a positive
# number wins — never a chained // compared against something, which is the
# shape that has bitten this project four times.
sub _space_from_metric {
    my ($self, $row) = @_;

    return (0, 0) unless ref($row) eq 'HASH';

    my $pick = sub {
        for my $field (@_) {
            my $value = $row->{$field};
            return $value + 0 if defined $value && $value =~ /^\d+(?:\.\d+)?$/;
        }
        return 0;
    };

    return (
        $pick->(qw(physical_total total_physical last_physical_total)),
        $pick->(qw(physical_used  total_used     last_physical_used)),
    );
}

# The newest record in a metrics reply.
#
# PowerStore returns these oldest-first, so the last row is the current one.
# Taking the first would report the capacity of whenever the window started.
sub _newest_metric {
    my ($self, $rows) = @_;

    return undef unless ref($rows) eq 'ARRAY' && @$rows;

    my $newest;
    for my $row (@$rows) {
        next unless ref($row) eq 'HASH';
        $newest = $row;
    }

    return $newest;
}

# Ask the metrics service for one entity's space figures.
#
# POST /metrics/generate { entity, entity_id, interval } is the documented
# way to read a metric, and it is what Dell's own python-powerstore SDK
# sends. The entity names are the space_metrics_by_* series. Returns undef
# rather than dying: the caller has other things to try.
sub _space_metrics {
    my ($self, $entity, $entity_id, %opts) = @_;

    return undef unless defined $entity_id && length $entity_id;

    my $rows = eval {
        $self->post('/metrics/generate',
            { entity => $entity, entity_id => $entity_id,
              interval => 'Five_Mins' }, %opts);
    };

    return $self->_newest_metric($rows);
}

# ($total, $used, $available) in bytes.
#
# Three sources, tried in order, because this is the one call that decides
# whether the storage shows up as active at all.
#
#   1. POST /metrics/generate for the cluster. This is the documented form
#      and the one Dell's SDK uses.
#   2. GET /space_metrics_by_cluster as a collection. Some versions expose
#      the series that way; on the ones that do not it is a 404 and costs one
#      round trip.
#   3. The same two, per appliance, summed.
#
# The plugin used to do (2) alone. space_metrics_by_cluster is an ENTITY NAME
# for the metrics service, not a REST collection — so on an array where that
# path does not exist, capacity could not be read at all, status() returned
# undef and the storage showed as inactive with nothing else wrong with it.
sub get_managed_capacity {
    my ($self, %opts) = @_;

    my @tried;

    my $cluster = eval { $self->cluster_get(%opts) };
    my $cluster_id = ref($cluster) eq 'HASH' ? $cluster->{id} : undef;

    if (defined $cluster_id) {
        push @tried, 'metrics/generate space_metrics_by_cluster';
        my $row = $self->_space_metrics('space_metrics_by_cluster',
            $cluster_id, %opts);
        my ($total, $used) = $self->_space_from_metric($row);
        return ($total, $used, $total - $used) if $total > 0;
    }

    push @tried, 'GET /space_metrics_by_cluster';
    my $rows = eval {
        $self->get('/space_metrics_by_cluster',
            { limit => 1, order => 'timestamp.desc' }, %opts);
    };
    if (ref($rows) eq 'ARRAY' && @$rows) {
        # This form is ordered newest-first by the order parameter above.
        my ($total, $used) = $self->_space_from_metric($rows->[0]);
        return ($total, $used, $total - $used) if $total > 0;
    }

    # Per appliance, summed. Same two forms, same order.
    push @tried, 'per-appliance metrics';
    my $appliances = eval {
        $self->_collection('/appliance', { select => 'id,name' }, %opts);
    } // [];

    my ($total, $used) = (0, 0);
    for my $appliance (@$appliances) {
        my $id = $appliance->{id} or next;

        my $row = $self->_space_metrics('space_metrics_by_appliance', $id, %opts);
        unless ($row) {
            my $legacy = eval {
                $self->get('/space_metrics_by_appliance',
                    { appliance_id => 'eq.' . $id, limit => 1,
                      order => 'timestamp.desc' }, %opts);
            };
            $row = (ref($legacy) eq 'ARRAY' && @$legacy) ? $legacy->[0] : undef;
        }

        my ($t, $u) = $self->_space_from_metric($row);
        $total += $t;
        $used  += $u;
    }

    die $self->_msg("could not determine the array's capacity. Tried: "
        . join('; ', @tried) . ". None returned a usable total, so this"
        . " storage cannot report its size. Check that the account may read"
        . " metrics.") . "\n" unless $total > 0;

    return ($total, $used, $total - $used);
}

# The recycle bin, for diagnosis only.
#
# A volume deleted from PowerStore Manager goes here: invisible to every volume
# listing, and the array still refuses its name. That is what made a create
# retry loop ask the wrong view ten times (issue #9).
#
# Dell's python-powerstore does NOT wrap these endpoints - grepping its
# constants.py for 'recycle' finds nothing - and an earlier version of this
# plugin concluded from that absence that there was nothing to ask. Wrong: the
# reporter read /recycle_bin, /recycle_bin/{id}, DELETE /recycle_bin/{id},
# POST /recycle_bin/{id}/recover and POST /recycle_bin/empty out of his own
# array's API reference (PowerStore REST API 4.3.0.0), where they are marked
# "Was added in version 3.5.0.0". An SDK not wrapping an endpoint says nothing
# about whether the array has it, and the array's own reference is the source
# tied to the firmware actually running.
#
# READ ONLY here, deliberately. Permanently deleting somebody's recycled volume
# to make room for a name is not this plugin's decision: the recycle bin is a
# data-protection feature and its whole point is that removal is deliberate.
#
# Returns undef when the array has no such endpoint - anything before 3.5.0.0 -
# which is why every caller treats this as a nice-to-have.
sub recycled_by_name {
    my ($self, $name, %opts) = @_;

    return undef unless defined $name && length $name;

    my $rows = eval {
        $self->get('/recycle_bin',
            { name => "eq.$name", select => 'id,name,type,deleted_timestamp' },
            %opts);
    };
    return undef if $@;

    return (ref($rows) eq 'ARRAY' && @$rows) ? $rows->[0] : undef;
}

# ---------------------------------------------------------------------------
# Volume groups
#
# A PowerStore volume belongs to AT MOST ONE volume group. Dell's own ansible
# module reads volume_groups[0], compares a single id, and refuses to reassign
# a group for an existing volume at all, pointing the caller at the Volume
# Group module instead. So a group is not an additive label: putting a volume
# in one takes it out of wherever it was.
#
# Everything here therefore separates "there is no such group" from "I could
# not ask" (rule 21a). The delete path is the reason: a listing that failed
# and a group that is empty look identical if the failure is swallowed, and
# the plugin then deletes a group that may hold somebody's protection policy.
# ---------------------------------------------------------------------------

sub _volume_group_select {
    return 'id,name,description,protection_policy_id,volumes(id,name,type)';
}

# The group, or undef when the array says there is none. Dies if it could not
# be asked.
sub volume_group_get_by_name {
    my ($self, $name, %opts) = @_;

    my $rows = $self->get('/volume_group',
        { name => "eq.$name", select => $self->_volume_group_select }, %opts);

    return (ref($rows) eq 'ARRAY' && @$rows) ? $rows->[0] : undef;
}

sub volume_group_get {
    my ($self, $id, %opts) = @_;

    return $self->get_or_undef("/volume_group/$id",
        { select => $self->_volume_group_select }, %opts);
}

# Which groups this volume is actually in, rather than which one this plugin
# would have put it in. Needed on the delete path: PowerStore refuses to delete
# a volume that is still a member (confirmed on a customer's array, issue #3),
# so the removal has to find the group even when somebody moved the volume.
#
# A select of its own, not _volume_select, because that one runs on every poll
# and this is wanted only when a volume is being deleted.
sub volume_groups_of {
    my ($self, $id, %opts) = @_;

    my $row = $self->get_or_undef("/volume/$id",
        { select => 'id,volume_groups(id,name)' }, %opts);

    return [] unless ref($row) eq 'HASH';

    my $groups = $row->{volume_groups};
    return [] unless ref($groups) eq 'ARRAY';

    return [ grep { ref($_) eq 'HASH' && defined $_->{id} && length $_->{id} }
             @$groups ];
}

sub volume_group_create {
    my ($self, $name, %opts) = @_;

    my $body = { name => $name };

    # Sent, and sent as false. Leaving it out is not neutral: Dell's snapshot
    # white paper (H18156), its ansible module and its Go client all say the
    # array makes a new group write-order consistent unless told otherwise,
    # and a consistent group refuses the one thing PVE does to its members -
    #
    #   Refreshing or Restoring an individual member volume of a write order
    #   consistent Volume Group is not supported. (0xE0A060030013)
    #
    # - which was every 'qm rollback' on a storage with per-VM groups, from
    # 0.8.18 to 0.8.32 (issue #12). This plugin snapshots and restores one
    # volume at a time because that is how PVE asks, and it takes no group
    # snapshot anywhere, so the setting protected nothing it does.
    $body->{is_write_order_consistent} = JSON::false;

    $body->{description} = $opts{description} if defined $opts{description};

    my $res = $self->post('/volume_group', $body, %opts);

    return ref($res) eq 'HASH' ? $res->{id} : undef;
}

# What a restore of one member needs to know about its group, and no more.
#
# A select of its own rather than one more field on _volume_group_select:
# that one serves the create and delete paths, which have run on a customer's
# array exactly as they are, and a field some firmware does not offer would
# fail the whole read for both of them.
sub volume_group_consistency {
    my ($self, $id, %opts) = @_;

    return $self->get_or_undef("/volume_group/$id",
        { select => 'id,name,description,protection_policy_id,'
                  . 'is_write_order_consistent' }, %opts);
}

# The setting "can be changed at the creation of the volume group or later"
# (H18156). Dell's own clients do it with a PATCH carrying this one field:
# python-powerstore's modify_volume_group, gopowerstore's VolumeGroupModify.
# NOT VERIFIED on an array.
sub volume_group_set_write_order_consistent {
    my ($self, $id, $enabled, %opts) = @_;

    return $self->patch("/volume_group/$id",
        { is_write_order_consistent => $enabled ? JSON::true : JSON::false },
        %opts);
}

sub volume_group_delete {
    my ($self, $id, %opts) = @_;
    return $self->_request('DELETE', "/volume_group/$id", undef, %opts);
}

sub volume_group_add_members {
    my ($self, $id, $volume_ids, %opts) = @_;

    return unless ref($volume_ids) eq 'ARRAY' && @$volume_ids;

    return $self->post("/volume_group/$id/add_members",
        { volume_ids => $volume_ids }, %opts);
}

sub volume_group_remove_members {
    my ($self, $id, $volume_ids, %opts) = @_;

    return unless ref($volume_ids) eq 'ARRAY' && @$volume_ids;

    return $self->post("/volume_group/$id/remove_members",
        { volume_ids => $volume_ids }, %opts);
}

# ---------------------------------------------------------------------------
# Volumes
# ---------------------------------------------------------------------------

# PowerStore rejects a size that is not a multiple of 8 KiB. Round up: a
# volume slightly larger than requested is harmless, one slightly smaller
# would silently truncate whatever PVE intends to put in it.
# NUMERIC, always. '0 +' is not decoration: PVE hands sizes in from a config
# file or a command line, where they are strings, and Perl's JSON encoder
# writes a scalar as a string whenever it carries one — which PowerStore
# rejects with "Instance type (string) does not match any allowed primitive
# type (allowed: [integer])". See next_free_lun for how a value that WAS a
# number acquires a string as well.
sub align_size {
    my ($class, $bytes) = @_;

    # The floor is applied FIRST, and it is not covered by the rounding: the
    # size that fails is one the granularity has nothing to say about. The
    # guest sees the size it asked for either way -- PVE reads an image's
    # size from its own metadata, and raw data at the start of a larger
    # device is still raw data, which is how LVM's 4 MiB extents have always
    # carried a 528 KiB EFI disk.
    $bytes = MIN_VOLUME_SIZE if $bytes < MIN_VOLUME_SIZE;

    my $granularity = SIZE_GRANULARITY;
    my $remainder = $bytes % $granularity;

    return 0 + $bytes unless $remainder;
    return 0 + ($bytes + ($granularity - $remainder));
}

sub volume_create {
    my ($self, $name, $size, %opts) = @_;

    my $body = {
        name => $name,
        size => $self->align_size($size),
    };

    for my $key (qw(appliance_id volume_group_id performance_policy_id
                    protection_policy_id description)) {
        $body->{$key} = $opts{$key} if defined $opts{$key};
    }

    my $res = $self->post('/volume', $body, %opts);

    return ref($res) eq 'HASH' ? $res->{id} : undef;
}

sub volume_get {
    my ($self, $id, %opts) = @_;
    return $self->get("/volume/$id", { select => $self->_volume_select }, %opts);
}

sub volume_get_by_name {
    my ($self, $name, %opts) = @_;

    my $rows = $self->get('/volume',
        { name => "eq.$name", select => $self->_volume_select }, %opts);

    return (ref($rows) eq 'ARRAY' && @$rows) ? $rows->[0] : undef;
}

# Every volume whose name starts with $prefix. Server-side filter, paged.
sub volume_list {
    my ($self, $prefix, %opts) = @_;

    my $params = { select => $self->_volume_select };
    $params->{type} = 'eq.Primary' unless $opts{include_snapshots};

    return $self->_collection('/volume', $params, %opts)
        unless defined $prefix && length $prefix;

    return $self->_collection_prefixed('/volume', $prefix, $params, %opts);
}

sub volume_delete {
    my ($self, $id, %opts) = @_;

    my $body = {};
    # A volume with snapshots needs them removed too; PowerStore refuses
    # otherwise.
    $body->{force_internal_snapshots} = JSON::true if $opts{force};

    return $self->_request('DELETE', "/volume/$id", (%$body ? $body : undef), %opts);
}

sub volume_resize {
    my ($self, $id, $size, %opts) = @_;
    return $self->patch("/volume/$id", { size => $self->align_size($size) }, %opts);
}

sub volume_rename {
    my ($self, $id, $name, %opts) = @_;
    return $self->patch("/volume/$id", { name => $name }, %opts);
}

# PowerStore reports 'naa.68ccf098...'; Linux multipath names the map
# '3' + the NAA registered designator.
#
# NOT YET VERIFIED against hardware. Confirm with
#   /lib/udev/scsi_id -g -u /dev/sdX
# before relying on it; see docs/TESTING.md.
sub wwn_to_wwid {
    my ($class, $wwn) = @_;

    return undef unless defined $wwn && length $wwn;

    my $naa = lc($wwn);
    $naa =~ s/^naa\.//;
    $naa =~ s/^0x//;
    $naa =~ s/[^0-9a-f]//g;

    return undef unless length($naa) >= 16;

    return '3' . $naa;
}

sub volume_get_wwid {
    my ($self, $id, %opts) = @_;

    my $vol = eval { $self->volume_get($id, %opts) } or return undef;

    return $self->wwn_to_wwid($vol->{wwn});
}

# ---------------------------------------------------------------------------
# Snapshots
#
# A PowerStore snapshot is itself a volume object, of type Snapshot, whose
# protection_data.source_id points at its parent.
# ---------------------------------------------------------------------------

sub snapshot_create {
    my ($self, $volume_id, $name, %opts) = @_;

    my $body = { name => $name };
    $body->{description} = $opts{description} if defined $opts{description};
    $body->{expiration_timestamp} = $opts{expires} if defined $opts{expires};

    my $res = $self->post("/volume/$volume_id/snapshot", $body, %opts);

    return ref($res) eq 'HASH' ? $res->{id} : undef;
}

sub snapshot_get_by_name {
    my ($self, $name, %opts) = @_;

    my $rows = $self->get('/volume',
        { name => "eq.$name", type => 'eq.Snapshot',
          select => $self->_volume_select }, %opts);

    return (ref($rows) eq 'ARRAY' && @$rows) ? $rows->[0] : undef;
}

# Snapshots of one volume, or every snapshot whose name starts with $prefix.
sub snapshot_list {
    my ($self, %opts) = @_;

    my $params = { type => 'eq.Snapshot', select => $self->_volume_select };

    if (defined $opts{source_id}) {
        # The source id lives inside a JSON column, hence the ->> operator.
        $params->{'protection_data->>source_id'} = 'eq.' . $opts{source_id};
    }
    return $self->_collection_prefixed('/volume', $opts{prefix}, $params, %opts)
        if defined $opts{prefix} && length $opts{prefix};

    return $self->_collection('/volume', $params, %opts);
}

sub snapshot_delete {
    my ($self, $id, %opts) = @_;
    return $self->_request('DELETE', "/volume/$id", undef, %opts);
}

# Restore a volume from one of its snapshots. create_backup_snap leaves a
# safety snapshot of the pre-restore content behind; it defaults off because
# PVE's own rollback semantics do not expect an extra snapshot to appear, and
# the array would keep accumulating them.
sub volume_restore {
    my ($self, $volume_id, $snapshot_id, %opts) = @_;

    my $body = {
        from_snap_id       => $snapshot_id,
        create_backup_snap => $opts{backup} ? JSON::true : JSON::false,
    };

    return $self->post("/volume/$volume_id/restore", $body, %opts);
}

# Thin clone of a volume or of a snapshot. Instant and space-efficient; this
# is what a PVE linked clone becomes.
sub volume_clone {
    my ($self, $source_id, $name, %opts) = @_;

    my $body = { name => $name };
    $body->{description}          = $opts{description} if defined $opts{description};
    $body->{host_id}              = $opts{host_id} if defined $opts{host_id};
    $body->{logical_unit_number}  = $opts{lun} if defined $opts{lun};

    my $res = $self->post("/volume/$source_id/clone", $body, %opts);

    return ref($res) eq 'HASH' ? $res->{id} : undef;
}

# ---------------------------------------------------------------------------
# Hosts
# ---------------------------------------------------------------------------

sub host_list {
    my ($self, $prefix, %opts) = @_;

    my $params = { select => 'id,name,os_type,host_initiators,host_group_id' };

    return $self->_collection_prefixed('/host', $prefix, $params, %opts)
        if defined $prefix && length $prefix;

    return $self->_collection('/host', $params, %opts);
}

sub host_get_by_name {
    my ($self, $name, %opts) = @_;

    my $rows = $self->get('/host',
        { name => "eq.$name",
          select => 'id,name,os_type,host_initiators,host_group_id' }, %opts);

    return (ref($rows) eq 'ARRAY' && @$rows) ? $rows->[0] : undef;
}

# $initiators is [ { port_name => 'iqn...', port_type => 'iSCSI' }, ... ]
sub host_create {
    my ($self, $name, $initiators, %opts) = @_;

    my $body = {
        name       => $name,
        os_type    => $opts{os_type} // 'Linux',
        initiators => $initiators,
    };
    $body->{description} = $opts{description} if defined $opts{description};

    my $res = $self->post('/host', $body, %opts);

    return ref($res) eq 'HASH' ? $res->{id} : undef;
}

sub host_add_initiators {
    my ($self, $host_id, $initiators, %opts) = @_;
    return $self->patch("/host/$host_id", { add_initiators => $initiators }, %opts);
}

sub host_remove_initiators {
    my ($self, $host_id, $port_names, %opts) = @_;
    return $self->patch("/host/$host_id", { remove_initiators => $port_names }, %opts);
}

sub host_delete {
    my ($self, $host_id, %opts) = @_;
    return $self->_request('DELETE', "/host/$host_id", undef, %opts);
}

# A host belongs to AT MOST ONE host group. The host object carries
# 'host_group_id', singular, where a volume carries 'volume_groups', a list.
# So joining a group means LEAVING whichever one the host is in, and since a
# host in a group is mapped through that group, leaving takes away every volume
# the old group was mapping to it. That is why nothing here ever moves a host
# between groups; see _hg_ensure_member.
sub _host_group_select {
    return 'id,name,description,hosts(id,name)';
}

sub host_group_get_by_name {
    my ($self, $name, %opts) = @_;

    my $rows = $self->get('/host_group',
        { name => "eq.$name", select => $self->_host_group_select }, %opts);

    return (ref($rows) eq 'ARRAY' && @$rows) ? $rows->[0] : undef;
}

# undef when there is no such group, dies when it could not be asked.
sub host_group_get {
    my ($self, $id, %opts) = @_;

    return $self->get_or_undef("/host_group/$id",
        { select => $self->_host_group_select }, %opts);
}

sub host_group_create {
    my ($self, $name, $host_ids, %opts) = @_;

    my $body = { name => $name };
    $body->{host_ids} = $host_ids
        if ref($host_ids) eq 'ARRAY' && @$host_ids;
    $body->{description} = $opts{description} if defined $opts{description};

    my $res = $self->post('/host_group', $body, %opts);

    return ref($res) eq 'HASH' ? $res->{id} : undef;
}

# add and remove are MUTUALLY EXCLUSIVE in one request: Dell's own client
# builds the payload with 'if remove_host_ids ... elsif add_host_ids', so a
# move is two calls with a window in between where the host is in no group at
# all. Nothing here performs that move, but the separation is why these are two
# methods rather than one.
sub host_group_add_hosts {
    my ($self, $id, $host_ids, %opts) = @_;

    return unless ref($host_ids) eq 'ARRAY' && @$host_ids;

    return $self->patch("/host_group/$id", { add_host_ids => $host_ids }, %opts);
}

sub host_group_remove_hosts {
    my ($self, $id, $host_ids, %opts) = @_;

    return unless ref($host_ids) eq 'ARRAY' && @$host_ids;

    return $self->patch("/host_group/$id", { remove_host_ids => $host_ids }, %opts);
}

sub host_group_delete {
    my ($self, $id, %opts) = @_;
    return $self->_request('DELETE', "/host_group/$id", undef, %opts);
}

# ---------------------------------------------------------------------------
# Mappings
# ---------------------------------------------------------------------------

sub mapping_list {
    my ($self, %opts) = @_;

    my $params = { select => 'id,host_id,host_group_id,volume_id,logical_unit_number' };
    $params->{host_id}       = 'eq.' . $opts{host_id}   if defined $opts{host_id};
    $params->{volume_id}     = 'eq.' . $opts{volume_id} if defined $opts{volume_id};
    $params->{host_group_id} = 'eq.' . $opts{host_group_id}
        if defined $opts{host_group_id};

    return $self->_collection('/host_volume_mapping', $params, %opts);
}

sub is_mapped {
    my ($self, $volume_id, $host_id, %opts) = @_;

    my $mappings = $self->mapping_list(volume_id => $volume_id, %opts);

    # A host that belongs to a host group can be reached by a mapping made to
    # the group, and such a row carries host_group_id with no host_id at all.
    # Reading only host_id would call the volume unmapped, attach it again,
    # and be refused by an array that is already doing what was asked.
    my $group_id = $opts{group_id};

    for my $mapping (@$mappings) {
        return 1 if defined $host_id && ($mapping->{host_id} // '') eq $host_id;
        return 1 if defined $group_id && length $group_id
                 && ($mapping->{host_group_id} // '') eq $group_id;
    }

    return 0;
}

# The lowest LUN id this host does not already use.
#
# PowerStore keeps SEPARATE automatic LUN id sequences for its UI and for
# REST/PSTCLI, and the REST sequence starts at 200 and only ever climbs. A
# workload that repeatedly attaches and detaches — which is exactly what a PVE
# cluster does — walks that counter past what the host OS scans, and new disks
# then simply never appear. Assigning the id ourselves keeps it dense and
# bounded. See docs/TROUBLESHOOTING.md.
sub next_free_lun {
    my ($self, $host_id, %opts) = @_;

    my $base = $opts{base} // MIN_LUN_ID;
    $base = MIN_LUN_ID if $base < MIN_LUN_ID;

    my $mappings = defined $host_id
        ? $self->mapping_list(host_id => $host_id, %opts)
        : [];

    # A LUN id is unique per host, and a mapping made to a host GROUP occupies
    # one on every host in it. Those rows carry host_group_id instead of
    # host_id, so a host in a group would otherwise be handed a LUN id one of
    # its group mappings already holds.
    if (defined $opts{group_id} && length $opts{group_id}) {
        push @$mappings,
            @{ $self->mapping_list(host_group_id => $opts{group_id}, %opts) };
    }

    my %used;
    for my $mapping (@$mappings) {
        my $lun = $mapping->{logical_unit_number};
        $used{$lun} = 1 if defined $lun;
    }

    for my $lun ($base .. MAX_LUN_ID) {
        # '0 +' because $used{$lun} has just used $lun as a hash key, which
        # stringifies it in place: the scalar then carries both an integer and
        # a string, and Perl's JSON encoder prefers the string. PowerStore
        # answers that with
        #   Validation failed: [Path '/logical_unit_number'] Instance type
        #   (string) does not match any allowed primitive type
        # and no volume can be mapped at all. Found on a customer's first
        # PowerStore run.
        return 0 + $lun unless $used{$lun};
    }

    die $self->_msg("host $host_id already uses every LUN id from $base to "
        . MAX_LUN_ID . ". Detach volumes it no longer needs, or lower"
        . " pstore-lun-id-base.") . "\n";
}

# EITHER a host or a host group, never both.
#
# PowerStore's attach and detach both document "Either host_id or
# host_group_id must be specified, but not both", and sending both is answered
# HTTP 500 'Volume internal error' (0xE0A080010052) rather than a clean 422 -
# so it reads as an array fault and not as a request this client should never
# have made. That failure blocked every disk creation on a node whose host is
# in a host group, from 0.8.10 until 0.8.24 (issue #11).
#
# The group wins when both are known, because a host that is in a group is
# mapped THROUGH the group: that is the whole reason the caller has both to
# hand. The host is still needed, but only to scan for a free LUN id, which is
# a separate question from who the mapping names.
#
# Returned as a list so the body cannot be built with both in it. The old
# shape assigned each independently, which is exactly how the caller's extra
# argument leaked into the request.
sub _mapping_target {
    my ($self, %opts) = @_;

    return (host_group_id => $opts{host_group_id})
        if defined $opts{host_group_id} && length $opts{host_group_id};

    return (host_id => $opts{host_id})
        if defined $opts{host_id} && length $opts{host_id};

    return ();
}

sub volume_attach {
    my ($self, $volume_id, %opts) = @_;

    my %target = $self->_mapping_target(%opts);

    die $self->_msg("volume_attach needs a host_id or a host_group_id") . "\n"
        unless %target;

    my $body = { %target };

    # Always pass the LUN id explicitly; see next_free_lun.
    if (defined $opts{lun}) {
        $body->{logical_unit_number} = 0 + $opts{lun};
    } else {
        # A group mapping occupies its LUN id on every member, so the id has
        # to be free across the group AND on the host this node is, which may
        # carry mappings of its own from before it joined. This is the one
        # place host_id is still wanted alongside a group, and it never
        # reaches the body.
        $body->{logical_unit_number} = 0 + $self->next_free_lun($opts{host_id},
            base     => $opts{lun_base},
            group_id => $opts{group_id} // $opts{host_group_id});
    }

    return $self->post("/volume/$volume_id/attach", $body, %opts);
}

sub volume_detach {
    my ($self, $volume_id, %opts) = @_;

    # Same rule as attach, and the callers here happen to pass only one today.
    # That is caller discipline rather than a guarantee, and the attach path
    # shows what happens when it slips.
    my %target = $self->_mapping_target(%opts);

    die $self->_msg("volume_detach needs a host_id or a host_group_id") . "\n"
        unless %target;

    return $self->post("/volume/$volume_id/detach", { %target }, %opts);
}

# ---------------------------------------------------------------------------
# Transport endpoints
# ---------------------------------------------------------------------------

# [ { portal => 'ip:3260', iqn => '...' }, ... ]
#
# The addresses and the target IQN come from different objects, so they are
# paired here by appliance where possible.
sub iscsi_portals {
    my ($self, %opts) = @_;

    my $select = 'id,address,appliance_id,purposes';

    # 'cs' is the contains operator for a list attribute, and the braces are
    # the array literal it takes. Neither has been seen answered by a real
    # appliance, and an operator the array rejects or reads differently gives
    # an empty result — which here means no portals, so no iSCSI login, so no
    # devices at all. The filter stays, because asking for every address on
    # the array is wasteful; but it is not what decides the answer.
    my $addresses = eval {
        $self->_collection('/ip_pool_address',
            { purposes => 'cs.{Storage_Iscsi_Target}', select => $select },
            %opts);
    } // [];

    unless (@$addresses) {
        my $all = eval {
            $self->_collection('/ip_pool_address', { select => $select }, %opts);
        } // [];

        $addresses = [ grep { _has_iscsi_purpose($_) } @$all ];

        $self->log_warn("the array returned no iSCSI target address for the"
            . " 'cs' filter, but " . scalar(@$addresses) . " of its addresses"
            . " carry the Storage_Iscsi_Target purpose. Using those. Please"
            . " report it.") if @$addresses;
    }

    return [] unless @$addresses;

    my $targets = eval {
        $self->_collection('/ip_port',
            { select => 'id,target_iqn,appliance_id' }, %opts);
    } // [];

    my $default_iqn;
    my %iqn_by_appliance;
    for my $target (@$targets) {
        my $iqn = $target->{target_iqn} or next;
        $default_iqn //= $iqn;
        my $appliance = $target->{appliance_id};
        $iqn_by_appliance{$appliance} //= $iqn if defined $appliance;
    }

    my @portals;
    for my $address (@$addresses) {
        my $ip = $address->{address} or next;
        my $iqn = $iqn_by_appliance{ $address->{appliance_id} // '' } // $default_iqn;
        next unless $iqn;
        push @portals, { portal => "$ip:3260", iqn => $iqn };
    }

    return \@portals;
}

# 'purposes' is a list. Whether it arrives as an arrayref or as one string
# depends on the appliance, so accept either rather than pick one.
sub _has_iscsi_purpose {
    my ($row) = @_;

    my $purposes = $row->{purposes} // return 0;
    my @values = ref($purposes) eq 'ARRAY' ? @$purposes : ($purposes);

    return (grep { defined && /Storage_Iscsi_Target/i } @values) ? 1 : 0;
}

# Target WWPNs, for checking that zoning reaches this array at all.
sub fc_ports {
    my ($self, %opts) = @_;

    return $self->_collection('/fc_port',
        { select => 'id,name,wwn,is_link_up,appliance_id' }, %opts);
}

# ---------------------------------------------------------------------------
# Jobs
#
# Some operations answer 202 with a job id instead of completing inline.
# ---------------------------------------------------------------------------

sub job_get {
    my ($self, $id, %opts) = @_;
    return $self->get("/job/$id", { select => 'id,state,phase,response_body,response_status' }, %opts);
}

sub wait_for_job {
    my ($self, $id, %opts) = @_;

    my $timeout  = $opts{timeout}  // JOB_POLL_TIMEOUT;
    my $interval = $opts{interval} // JOB_POLL_INTERVAL;
    my $deadline = time() + $timeout;

    while (time() < $deadline) {
        my $job = eval { $self->job_get($id) };
        if ($job) {
            my $state = $job->{state} // '';
            return $job if $state =~ /^(?:COMPLETED|COMPLETED_WITH_ERRORS)$/i;
            die $self->_msg("array job $id ended in state '$state'") . "\n"
                if $state =~ /^(?:FAILED|ABORTED)$/i;
        }
        sleep($interval);
    }

    die $self->_msg("array job $id did not finish within ${timeout}s") . "\n";
}

1;

__END__

=head1 NAME

PVE::Storage::Custom::DellEMC::PowerStore::API - PowerStore REST client

=head1 SYNOPSIS

    my $api = PVE::Storage::Custom::DellEMC::PowerStore::API->new(
        portal   => '10.0.0.5',
        username => 'pveadmin',
        password => 'secret',
        storeid  => 'ps1',
        type     => 'dellpowerstore',
    );

    my $id = $api->volume_create('pve-ps1-100-disk0', 32 * 1024**3);
    $api->volume_attach($id, host_id => $host_id);

=head1 STATUS

The endpoint paths, field names and filter syntax here follow the PowerStore
4.x REST documentation and are B<not yet verified against hardware>. Check
them against the appliance's own Swagger UI at C<https://<mgmt-ip>/swaggerui>
before relying on them. See docs/TESTING.md.

=head1 NOTES

Listing always filters server-side. This plugin polls every ten seconds per
node; fetching the whole volume inventory to filter locally would put that
load on the array's management gateway continuously.

LUN ids are assigned by this client rather than by the array. PowerStore's
REST-side automatic sequence starts at 200 and never reuses an id, so a
cluster that repeatedly attaches and detaches volumes eventually exceeds what
the host scans and new disks stop appearing.

=head1 AUTHOR

Jason Cheng (Jason Tools) <jason@jason.tools>

=head1 LICENSE

MIT License

=cut
